# Changelog

## 1.0.5
- Fixed input detection for games using Rewired input system
- Now uses Windows API (GetAsyncKeyState) to detect F8 key press
- Works regardless of game's input system

## 1.0.4
- Added alternative input detection via OnGUI events
- Added debug logging for UI toggle

## 1.0.3
- Version bump to force Thunderstore cache refresh

## 1.0.2
- Added missing kcp2k.dll dependency (fixes mod not loading)

## 1.0.1
- Updated README with server hosting information
- Fixed GitHub repository links

## 1.0.0
- Initial release
- Direct IP connection to Techtonica dedicated servers
- In-game UI with F8 hotkey
- KCP transport for reliable UDP connections
- Auto-saves last connected server
