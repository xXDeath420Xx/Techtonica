# Changelog

## 1.0.11
- Updated changelog with all version history

## 1.0.10
- Updated mod icon

## 1.0.9
- Fixed Update/OnGUI not being called by creating dedicated MonoBehaviour
- Changed keybind from F8 to F11 (F1-F10 are used in-game)

## 1.0.8
- Added debug logging to diagnose input detection issues

## 1.0.7
- Added CHANGELOG.md to package

## 1.0.6
- Attempted changelog fix

## 1.0.5
- Fixed input detection for games using Rewired input system
- Now uses Windows API (GetAsyncKeyState) to detect key presses
- Works regardless of game's input system

## 1.0.4
- Added alternative input detection via OnGUI events
- Added debug logging for UI toggle

## 1.0.3
- Version bump to force Thunderstore cache refresh

## 1.0.2
- Added missing kcp2k.dll dependency (fixes mod not loading)

## 1.0.1
- Updated README with server hosting information
- Fixed GitHub repository links

## 1.0.0
- Initial release
- Direct IP connection to Techtonica dedicated servers
- In-game UI with F8 hotkey
- KCP transport for reliable UDP connections
- Auto-saves last connected server
